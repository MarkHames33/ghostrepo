# @tryghost/kg-markdown-html-renderer

## 7.2.4

### Patch Changes

- Documented the package API and corrected the development instructions in the README

- Updated dependencies
